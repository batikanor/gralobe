import { App } from './App';
import './style.css';

// Start the application
new App();
