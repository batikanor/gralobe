# Custom Statistics Example

Shows how to display your own data on the globe using ISO 3166-1 numeric country codes.

```bash
npm install
npm run dev
```
