# Basic Gralobe Example

```bash
npm install
npm run dev
```
