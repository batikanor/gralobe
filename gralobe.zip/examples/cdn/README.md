# CDN Example (No Build Tools)

This example works by just opening the HTML file in a browser - no npm install needed!

**Note:** Due to CORS, you may need to serve it locally:

```bash
npx serve .
```

Or use VS Code's Live Server extension.
